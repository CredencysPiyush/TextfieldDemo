//
//  ViewController.swift
//  TextfieldDemo
//
//  Created by piyush sinroja on 21/12/16.
//  Copyright © 2016 piyush sinroja. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtDigit: UITextField!
    
    var strDigit: String = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let label = UILabel(frame: CGRect(x :0,y :0,width :10,height: 10))
        label.text = "$"
        self.txtDigit.leftViewMode = .always
        self.txtDigit.leftView = label
        
        txtDigit.layer.cornerRadius = 4.0
        txtDigit.layer.masksToBounds = true
        txtDigit.layer.borderColor = UIColor.lightGray.cgColor
        txtDigit.layer.borderWidth = 1.0
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return true
    }

    func textField(_ textFieldToChange: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if  textFieldToChange == txtDigit{
            let aSet = NSCharacterSet(charactersIn:"0123456789").inverted
            let compSepByCharInSet = string.components(separatedBy: aSet)
            let numberFiltered = compSepByCharInSet.joined(separator: "")

            if numberFiltered == "" {
                let new  = txtDigit.text!
                let fsf = new.substring(to: new.index(new.endIndex, offsetBy: -1))
                let currentString = fsf
                let findStr = commaStrSet(currentString: currentString)
                txtDigit.text = findStr
                return false
            }
            else{
                let currentString = (textFieldToChange.text! as NSString)
                    .replacingCharacters(in: range, with: string)
                let findStr = commaStrSet(currentString: currentString)
                txtDigit.text = findStr
            }
        }
        return false
    }
    
    func commaStrSet(currentString: String) -> String {
        var replaceStr = currentString.replacingOccurrences(of: ",", with: "")
        let length = replaceStr.characters.count
        switch length {
        case 4:
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 1))
        case 5:
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 2))
        case 6:
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 1))
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 5))
        case 7:
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 2))
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 5))
        case 8:
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 1))
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 4))
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 7))
        case 9:
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 2))
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 5))
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 8))
        case 10:
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 1))
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 4))
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 7))
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 10))
        case 11,12,13,14,15:
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 1))
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 4))
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 7))
            replaceStr.insert(",", at: replaceStr.index(replaceStr.startIndex, offsetBy: 10))
        default:
            break
        }
        
        return replaceStr
    }
}

